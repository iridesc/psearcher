# psearcher
psearcher is a web search interface for python3.